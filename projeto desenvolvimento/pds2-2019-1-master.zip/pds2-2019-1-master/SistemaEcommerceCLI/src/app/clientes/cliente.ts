export class Cliente {

    codigo: number;
    nome: string;
    cargo: string;
    endereco: string;
    cidade: string;
    cep: string;
    pais: string;
    telefone: string;
    fax: string;
}
